<?php
$server="localhost";
$username="root";
$password="";
$database="srmid";

$con = mysqli_connect($server, $username, $password, $database);
?>